package edu.ann72nau.anagramgame;

/**
 * Created by Alex on 2017-10-15.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.DatabaseUtils;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class WordDatabase extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "WordDatabase.db";
    private static final String WORD_TABLE_NAME = "anagrams";
    private static final String WORD_COLUMN_ID = "id";
    private static final String WORD_COLUMN_SCRAMBLED = "scrambled";
    private static final String WORD_COLUMN_CORRECT = "correct";
    private static final String WORD_COLUMN_DIFFICULTY = "difficulty";

    public WordDatabase(Context context){
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL( "CREATE TABLE " + WORD_TABLE_NAME + "("
                + WORD_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + WORD_COLUMN_SCRAMBLED  +" TEXT, "
                + WORD_COLUMN_CORRECT + " TEXT, "
                + WORD_COLUMN_DIFFICULTY + " TEXT, )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXIST anagrams");
        onCreate(db);
    }

    // Insert Words for Easy Difficulty
    public void insertWordsEasy(){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("scrambled", "AFRICAN OIL");
        contentValues.put("scrambled", "WARD");
        contentValues.put("scrambled", "HATING SNOW");
        contentValues.put("scrambled", "OURS");
        contentValues.put("scrambled", "VETO");

        contentValues.put("correct", "CALIFORNIA");
        contentValues.put("correct", "DRAW");
        contentValues.put("correct", "WASHINGTON");
        contentValues.put("correct", "SOUR");
        contentValues.put("correct", "VOTE");

        contentValues.put("difficulty", "Easy");
        contentValues.put("difficulty", "Easy");
        contentValues.put("difficulty", "Easy");
        contentValues.put("difficulty", "Easy");
        contentValues.put("difficulty", "Easy");

        db.insert("anagrams", null, contentValues);
        db.close();
    }

    // Insert Words for Medium Difficulty
    public void insertWordsMedium(){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("scrambled", "ONLY PROPER IDEA");
        contentValues.put("scrambled", "LET THINGS IN");
        contentValues.put("scrambled", "HER HOTEL TRUCK");
        contentValues.put("scrambled", "AVENGE");
        contentValues.put("scrambled", "HASTEN");

        contentValues.put("correct", "ORDINARY PEOPLE");
        contentValues.put("correct", "SILENT NIGHT");
        contentValues.put("correct", "THE HURT LOCKER");
        contentValues.put("correct", "GENEVA");
        contentValues.put("correct", "ATHENS");

        contentValues.put("difficulty", "Medium");
        contentValues.put("difficulty", "Medium");
        contentValues.put("difficulty", "Medium");
        contentValues.put("difficulty", "Medium");
        contentValues.put("difficulty", "Medium");

        db.insert("anagrams", null, contentValues);
        db.close();
    }

    // Insert Words for Hard Difficulty
    public void insertWordsHard(){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("scrambled", "SO ACKNOWLEDGE SIGN");
        contentValues.put("scrambled", "INNER WORLD WANTED");
        contentValues.put("scrambled", "REAL BACON");
        contentValues.put("scrambled", "A DARN LONG ERA");
        contentValues.put("scrambled", "CRAZY ROYAL HAT");

        contentValues.put("correct", "GOOD KING WENCESLAS");
        contentValues.put("correct", "WINTER WONDERLAND");
        contentValues.put("correct", "BARCELONA");
        contentValues.put("correct", "RONALD REAGAN");
        contentValues.put("correct", "ZACHARY TAYLOR");

        contentValues.put("difficulty", "Hard");
        contentValues.put("difficulty", "Hard");
        contentValues.put("difficulty", "Hard");
        contentValues.put("difficulty", "Hard");
        contentValues.put("difficulty", "Hard");

        db.insert("anagrams", null, contentValues);
        db.close();
    }

    public String getWord(int id, String columnName){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + columnName +" FROM " + WORD_TABLE_NAME + " WHERE id =" + id ;

        Cursor res = db.rawQuery(query, null);
        //Cursor res = db.query(WORD_TABLE_NAME, new String[] { WORD_COLUMN_ID,
        //        WORD_COLUMN_SCRAMBLED}, WORD_COLUMN_ID + "=?", new String[] {
        //        String.valueOf(id)}, null, null, null, null);

        if (res != null)
            res.moveToFirst();

        String word = String.valueOf(res);
        res.close();
        // Return the word
        return word;
    }

    // Get the number of words for a difficulty
    public int numberOfRows(String difficulty){
        String countQuery = "SELECT * FROM " + WORD_TABLE_NAME + " WHERE difficulty =" + difficulty;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery(countQuery, null);
        res.close();
        // int numRows = (int) DatabaseUtils.queryNumEntries(db, WORD_TABLE_NAME, difficulty);
        //return numRows;
        return res.getCount();
    }

    // Check if submitted word is correct
    public boolean checkWord(String word, int id){
        SQLiteDatabase db = this.getReadableDatabase();
        String currentWord = getWord(id, WORD_COLUMN_CORRECT).toString();

        if (word.equals(currentWord)){
            return true;
        }
        else{
            return false;
        }
    }
}
