package edu.ann72nau.anagramgame;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.support.annotation.Nullable;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class GamePage extends Activity {

    private RadioGroup radioDifficulty;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_page);

        Button button_home = (Button) findViewById(R.id.button7);
        Button button_about = (Button) findViewById(R.id.button8);
        Button button_results = (Button) findViewById(R.id.button9);
        radioDifficulty = (RadioGroup) findViewById(R.id.radioGroup);
        Button startButton = (Button) findViewById(R.id.button10);

        button_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GamePage.this, HomePage.class));
            }
        });

        button_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GamePage.this, AboutPage.class));
            }
        });

        button_results.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GamePage.this, ViewResults.class));
            }
        });

        // Edit so that it will start one of the game pages based on which radio button is selected
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioDifficulty.getCheckedRadioButtonId();
                RadioButton radioSelectButton = (RadioButton) findViewById(selectedId);

                switch (radioSelectButton.getText().toString()){
                    case "Easy":
                        startActivity(new Intent(GamePage.this, EasyGame.class));

                    case "Medium":
                        startActivity(new Intent(GamePage.this, MediumGame.class));

                    case "Hard":
                        startActivity(new Intent(GamePage.this, HardGame.class));
                }
            }
        });

    }

}
