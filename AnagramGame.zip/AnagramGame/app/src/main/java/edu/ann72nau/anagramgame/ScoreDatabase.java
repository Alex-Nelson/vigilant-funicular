package edu.ann72nau.anagramgame;

/**
 * Created by Alex on 2017-10-15.
 */

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class ScoreDatabase extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "ScoreDatabase.db";
    private static final String SCORE_TABLE_NAME = "score";
    private static final String SCORE_ID = "id";
    private static final String SCORE_CORRECT_GAME = "correct_game";
    private static final String SCORE_MISSED_GAME = "missed_game";
    private static final String SCORE_INCORRECT_GAME = "incorrect_game";
    private static final String SCORE_TOTAL_GAME = "total_game";

    public ScoreDatabase(Context context){
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE " + SCORE_TABLE_NAME + " ("
            + SCORE_ID + "INTEGER PRIMARY KEY AUTOINCREMENT, "
            + SCORE_CORRECT_GAME + " INTEGER, "
            + SCORE_MISSED_GAME + " INTEGER, "
            + SCORE_INCORRECT_GAME + " INTEGER, "
            + SCORE_TOTAL_GAME + "INTEGER, )" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS score");
        onCreate(db);
    }

    public int getScore(int id, String columnName){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery(" select * from score where id=" +id +" and SCORE_COLUMN_NAME="
                +columnName +"", null);

        res.close();
        return Integer.valueOf(res.toString());
    }

    public int getTotalScore(String columnName){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT sum(" +columnName  + ") FROM SCORE";

        Cursor res = db.rawQuery(query, null);

        if (res == null)
            return 0;

        else{
            res.moveToFirst();
            res.close();
            return Integer.valueOf(res.toString());
        }

    }

    public int numberofRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, SCORE_TABLE_NAME);
        return numRows;
    }

    // Update the score value
    public boolean updateScore(int id, int scoreValue, String columnName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(columnName, scoreValue);
        db.update("score", contentValues, "id = ? ", new String[] {Integer.toString(id)});
        return true;
    }
}
