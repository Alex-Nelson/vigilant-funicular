package edu.ann72nau.anagramgame;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.support.annotation.Nullable;

public class ViewResults extends Activity {

    private ScoreDatabase sdb;
    TextView correct;
    TextView missed;
    TextView incorrect;
    TextView total;

    int correctScore = 0;
    int missedScore = 0;
    int incorrectScore = 0;
    int totalScore = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_results);

        sdb = new ScoreDatabase(this);

        Button button_home = (Button) findViewById(R.id.button4);
        Button button_about = (Button) findViewById(R.id.button5);
        Button button_game = (Button) findViewById(R.id.button6);
        correct = (TextView) findViewById(R.id.textViewCorrect);
        missed = (TextView) findViewById(R.id.textViewMissed);
        incorrect = (TextView) findViewById(R.id.textViewIncorrect);
        total = (TextView) findViewById(R.id.textViewTotal);

        correctScore = sdb.getTotalScore("correct_game");
        missedScore = sdb.getTotalScore("missed_game");
        incorrectScore = sdb.getTotalScore("incorrect_game");
        totalScore = sdb.getTotalScore("total_game");

        correct.setText(String.valueOf(correctScore));
        correct.setClickable(false);
        missed.setText(String.valueOf(missedScore));
        missed.setClickable(false);
        incorrect.setText(String.valueOf(incorrectScore));
        incorrect.setClickable(false);
        total.setText(String.valueOf(totalScore));
        total.setClickable(false);

        button_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ViewResults.this, HomePage.class));
            }
        });

        button_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ViewResults.this, AboutPage.class));
            }
        });

        button_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ViewResults.this, GamePage.class));
            }
        });
    }
}
