package edu.ann72nau.anagramgame;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.CountDownTimer;

public class EasyGame extends Activity {

    public int counter;

    private WordDatabase wdb;
    private ScoreDatabase sdb;

    CountDownTimer cTimer = null;
    int correct_score = 0;
    int missed_score = 0;
    int incorrect_score = 0;
    int total_score = 0;
    int word_id = 0;
    TextView curr_word;
    TextView timerText;
    TextView userWord;

    int numberOfWords = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easy_game);
        Button button_submit = (Button) findViewById(R.id.button21);
        Button button_skip = (Button) findViewById(R.id.button22);
        Button button_quit = (Button) findViewById(R.id.button23);
        curr_word = (TextView) findViewById(R.id.textViewWord);
        timerText = (TextView) findViewById(R.id.textViewTimer);
        userWord = (TextView) findViewById(R.id.editTextWord);

        wdb = new WordDatabase(this);
        wdb.insertWordsEasy();
        wdb.insertWordsMedium();
        wdb.insertWordsHard();

        startTimer();

        while (numberOfWords < wdb.numberOfRows("Easy")){

            String word = wdb.getWord(numberOfWords, "scrambled");
            word_id = numberOfWords;

            curr_word.setText(word);
            curr_word.setClickable(false);

            button_submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Check word based on submission
                    boolean check = wdb.checkWord(userWord.getText().toString(), word_id);

                    // Increment correct and total if correct
                    if (check){
                        correct_score++;
                        sdb.updateScore(word_id, correct_score, "correct_game");
                        total_score++;
                        sdb.updateScore(word_id, total_score, "total_game");
                    }

                    // Increment incorrect if wrong
                    else{
                        incorrect_score++;
                        sdb.updateScore(word_id, incorrect_score, "incorrect_game");
                    }

                    numberOfWords++;
                }
            });

            button_skip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    missed_score++;
                    sdb.updateScore(1, missed_score, "missed_game");

                    numberOfWords++;
                }
            });

            button_quit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    open(v);
                }
            });

        }

        // Go to the Results page when done
        startActivity(new Intent(EasyGame.this, ViewResults.class));
    }

    // Open an alert dialog if user wants to quit their current game
    public void open(View view){
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure you want to quit ?");

        // Send user back to the Game Page screen if they select "Yes"
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(EasyGame.this, "Quitting Current Game.",
                                Toast.LENGTH_LONG).show();
                        cancelTimer();
                        startActivity(new Intent(EasyGame.this, GamePage.class));
                    }
        });

        // Dismiss the alert dialog if user selects "No"
        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void startTimer() {
        cTimer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerText.setText(String.valueOf(counter));
                counter++;
            }

            @Override
            public void onFinish() {
                timerText.setText("Game is Done");
            }
        };
        cTimer.start();
    }

    private void cancelTimer(){
        if (cTimer != null){
            cTimer.cancel();
        }

    }

}
